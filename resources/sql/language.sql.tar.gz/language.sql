-----------------------------------------------------------------------------
-- The contents of this file are subject to the Mozilla Public License
-- Version 1.1 (the "License"); you may not use this file except in
-- compliance with the License. You may obtain a copy of the License at
-- http://www.mozilla.org/MPL/
-- 
-- Software distributed under the License is distributed on an "AS IS"
-- basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
-- License for the specific language governing rights and limitations
-- under the License.
-- 
-- The Original Code is hib_lemmas.sql.
-- 
-- The Initial Developer of the Original Code is the Tufts University Perseus 
-- project (http://www.perseus.tufts.edu).
-- Portions created by Initial Developer are Copyright (C) (unknown date).
-- All Rights Reserved.
-- 
-- Contributor(s): Roger Grantham (created this file to explicitly describe the
--  implicit language codes originally in hib_lemmas.sql)
-----------------------------------------------------------------------------

CREATE TABLE ARS.language(
  id int PRIMARY KEY NOT NULL,
  name varchar(5) NOT NULL);

INSERT INTO ARS.language VALUES
        (2, 'greek'),
        (3, 'latin');
